

/**
 * @author uidn7735
 * @version 1.0
 * @created 25-Nov-2017 4:00:30 PM
 */
public class <<DatabaseAdmin>> extends <<User>> {

	private char AdminLoginName;
	private char AdminLoginPassword;

	public <<DatabaseAdmin>>(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

	public void addAge(){

	}

	public void addGender(){

	}

	public void addName(){

	}

	public boolean authenticateUser(){
		return false;
	}

	public char getAdminLoginName(){
		return 0;
	}

	public char getAdminPassword(){
		return 0;
	}

	public int getAge(){
		return 0;
	}

	public char getGender(){
		return 0;
	}

	public char getName(){
		return 0;
	}

}