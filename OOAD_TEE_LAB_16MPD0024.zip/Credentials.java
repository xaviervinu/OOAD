

/**
 * @author uidn7735
 * @version 1.0
 * @created 25-Nov-2017 4:00:34 PM
 */
public class <<Credentials>> {

	private char LoginId;
	private char Password;

	public <<Credentials>>(){

	}

	public void finalize() throws Throwable {

	}

}