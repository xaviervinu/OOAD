

/**
 * @author uidn7735
 * @version 1.0
 * @created 25-Nov-2017 4:00:33 PM
 */
public class Passenger {

	private int Age;
	private char Gender;
	private char Name;
	public <<Ticket>> m_<<Ticket>>;

	public Passenger(){

	}

	public void finalize() throws Throwable {

	}

	public void getPassengerAge(){

	}

	public void getPassengerGender(){

	}

	public void getPassengerName(){

	}

}