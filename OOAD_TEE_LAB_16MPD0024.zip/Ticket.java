

/**
 * @author uidn7735
 * @version 1.0
 * @created 25-Nov-2017 4:00:32 PM
 */
public class <<Ticket>> {

	private int TicketNumber;

	public <<Ticket>>(){

	}

	public void finalize() throws Throwable {

	}

	public void getTicketNumber(){

	}

}