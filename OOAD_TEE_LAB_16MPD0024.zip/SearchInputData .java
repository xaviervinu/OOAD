

/**
 * @author uidn7735
 * @version 1.0
 * @created 25-Nov-2017 4:00:27 PM
 */
public class << SearchInputData >> {

	private int DepartureDate;
	private char DestinationCity;
	private int NoOfTravellers;
	private char OriginCity;
	private int ReturnDate;

	public << SearchInputData >>(){

	}

	public void finalize() throws Throwable {

	}

	public void addDepartureDate(){

	}

	public void addDestinationCity(){

	}

	public void addNumberOfTravellers(){

	}

	public void addOriginCity(){

	}

	public void addReturnDate(){

	}

	public int getDepartureDate(){
		return 0;
	}

	public char getDestinationCity(){
		return 0;
	}

	public int getNoOfTravellers(){
		return 0;
	}

	public char getOriginCity(){
		return 0;
	}

	public int getReturnDate(){
		return 0;
	}

	public void SearchFlight(){

	}

}