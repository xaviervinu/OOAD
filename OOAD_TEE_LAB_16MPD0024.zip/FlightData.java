

/**
 * @author uidn7735
 * @version 1.0
 * @created 25-Nov-2017 4:00:31 PM
 */
public class <<FlightData>> {

	private int ArrivalTime;
	private int DepartTime;
	private <<User>> FlightID;
	private char Name;
	public <<Ticket>> m_<<Ticket>>;

	public <<FlightData>>(){

	}

	public void finalize() throws Throwable {

	}

}