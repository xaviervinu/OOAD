

/**
 * @author uidn7735
 * @version 1.0
 * @created 25-Nov-2017 4:00:29 PM
 */
public class <<User>> {

	private int Age;
	private char Gender;
	private char LoginId;
	private char LoginPassword;
	private char Name;
	public << SearchInputData >> m_<< SearchInputData >>;
	public <<Ticket>> m_<<Ticket>>;
	public <<Credentials>> m_<<Credentials>>;

	public <<User>>(){

	}

	public void finalize() throws Throwable {

	}

	public void addAge(){

	}

	public void addGender(){

	}

	public void addName(){

	}

	public int getAge(){
		return 0;
	}

	public char getGender(){
		return 0;
	}

	public char getName(){
		return 0;
	}

}